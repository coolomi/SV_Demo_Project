package com.qk.sv.controller;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//This section defines a REST API Controller
@RestController
public class MainController {

	private static final Logger logger = LoggerFactory.getLogger(MainController.class);

	// This is a request mapping section
	@RequestMapping(value = "/test/static", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public String test_staticResponse(@RequestBody String requestBody) {

		// This is a static response
		String static_response = "{\"response\" : \"Hi Omkar\"}";

		logger.info("===========================================");

		// Dispatching static response
		return static_response;
	}

	// This is a request mapping section
	@RequestMapping(value = "/test/dynamic", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public String test_dynamicResponse(@RequestBody String requestBody) {

		JSONObject requestJson = new JSONObject(requestBody);

		// Fetch "name" parameter value from incoming requestBody
		String name = requestJson.getString("name");

		// This is a dynamic response
		String dynamic_response = "{\"response\" : \"Hi " + name + "\"}";

		logger.info("===========================================");

		// Dispatching dynamic response
		return dynamic_response;
	}
}
